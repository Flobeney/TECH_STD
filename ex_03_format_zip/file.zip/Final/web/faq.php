<?php
/*
Nom du fichier : faq.php
Auteur : Florent BENEY
Date de création : 06.06.2018
Description : Cette page permet à l'utilisateur de consulter la FAQ du site
*/
?>
<embed src="ModeEmploi.pdf" width="100%" height="100%" type='application/pdf'>
