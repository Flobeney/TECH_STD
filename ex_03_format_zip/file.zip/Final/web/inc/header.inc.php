<div class="home" id="home">
    <div class="container">
        <div class="header-content">
            <br>
            <a href="accueil.php" title="Retour à l'accueil"><h1>DevSkills</h1></a>
            <p>Site de tutoriels informatiques</p>
        </div>
    </div>
</div>
