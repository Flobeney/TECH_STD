<!-- JavaScript Libraries -->
<script src="assets/lib/jquery/jquery.min.js"></script>
<script src="assets/lib/jquery/jquery-migrate.min.js"></script>
<script src="assets/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/lib/typed/typed.js"></script>
<script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
<script src="assets/lib/magnific-popup/magnific-popup.min.js"></script>
<script src="assets/lib/isotope/isotope.pkgd.min.js"></script>

<!-- Template Main Javascript File -->
<script src="assets/js/main.js"></script>
